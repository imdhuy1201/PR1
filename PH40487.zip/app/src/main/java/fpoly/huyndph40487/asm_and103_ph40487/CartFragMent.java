package fpoly.huyndph40487.asm_and103_ph40487;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class CartFragMent extends Fragment {


    public CartFragMent() {
        // Required empty public constructor
    }

    public static CartFragMent newInstance() {
        CartFragMent fragment = new CartFragMent();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_cart_frag_ment, container, false);
    }
}